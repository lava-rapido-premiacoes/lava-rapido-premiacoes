# 🚗 Lava Rápido — Sistema de Premiações

Dashboard de acompanhamento mensal de premiações, bônus e produção de lavagens.

---

## 📁 Estrutura do Repositório

```
lava-rapido-premiacoes/
│
├── dashboard.html          ← Dashboard visual (abre no navegador)
├── dados.json              ← Fonte de dados do dashboard
├── README.md               ← Este arquivo
│
└── planilhas/
    ├── 2026-03-marco/
    │   └── premiacao_marco_2026.xlsx
    ├── 2026-04-abril/
    │   └── premiacao_abril_2026.xlsx
    └── ...
```

---

## 🚀 Como usar

### 1. Visualizar o Dashboard

**Localmente:**
```bash
# Opção A — Python (recomendado)
python -m http.server 8080
# Abra: http://localhost:8080/dashboard.html

# Opção B — Node.js
npx serve .
```

**Via GitHub Pages:**
1. Vá em **Settings → Pages**
2. Source: `Deploy from branch → main → / (root)`
3. Acesse: `https://SEU_USUARIO.github.io/lava-rapido-premiacoes/dashboard.html`

---

### 2. Atualizar os dados ao fechar o mês

Ao fechar cada mês, faça:

#### Passo 1 — Suba o Excel na pasta do mês
```
planilhas/2026-04-abril/premiacao_abril_2026.xlsx
```

#### Passo 2 — Abra o `dados.json` e adicione o novo mês

Copie o bloco abaixo e preencha com os totais do **Resumo Mensal** da planilha:

```json
{
  "mes": "Abril 2026",
  "ano": 2026,
  "mes_num": 4,
  "semanas": [
    {
      "semana": 1,
      "periodo": "04/04 → 10/04",
      "pagamento": "11/04/2026",
      "eficiente_ii": 0,
      "supremas": 0,
      "dias_com_meta": 0,
      "pool_total": 0.00
    }
  ],
  "lavadores": [
    {
      "nome": "Lavador 1",
      "dias_trabalhados": 0,
      "bonus_pontualidade": 0.00,
      "bonus_sabado": 0.00,
      "ajuda_custo": 0.00,
      "premiacao_lavagens": 0.00,
      "total_mes": 0.00
    }
  ]
}
```

#### Passo 3 — Salve e suba no GitHub
```bash
git add .
git commit -m "Fechamento Abril 2026"
git push
```

---

## 📊 O que o Dashboard mostra

| Seção | Descrição |
|---|---|
| **Cards de resumo** | Supremas, pool total, total pago, taxa de metas |
| **Gráfico Supremas** | Barras por semana do mês selecionado |
| **Gráfico Pool** | Linha de evolução do pool semanal |
| **Semanas** | Detalhe de cada semana com data de pagamento |
| **Ranking** | Lavadores ordenados por total recebido no mês |
| **Metas** | Taxa de dias com meta batida por semana |
| **Histórico** | Tabela comparativa de todos os meses |

---

## 🗓️ Ciclo de pagamento

- **Semana:** Sábado → Sexta
- **Pagamento:** Todo Sábado (fechamento da semana anterior)

---

## ⚙️ Composição do pagamento semanal

| Componente | Valor |
|---|---|
| Ajuda de Custo | R$ 1.000,00 (fixo) |
| Bônus Pontualidade | R$ 40,00 (sem atrasos na semana) |
| Bônus Sábado | R$ 30,00 (presente no sábado) |
| Premiação Lavagens | Pool ÷ nº presentes no dia |

---

## 🏆 Sistema de metas (Supremas por dia)

| Meta | Supremas | Bônus/pessoa |
|---|---|---|
| 🥉 Meta 1 | ≥ 5 | R$ 10,00 |
| 🥈 Meta 2 | ≥ 10 | R$ 25,00 |
| 🥇 Meta 3 | ≥ 15 | R$ 45,00 |
